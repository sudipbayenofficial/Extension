// ==========================================
// SECOND BRAIN — App Controller (app.js)
// ==========================================

const App = {
    currentView: 'dashboard',

    async init() {
        // Load saved theme immediately
        this.loadTheme();

        // Initialize database first
        await DB.init();

        // Initialize sync and load from directory if connected
        await Sync.init();
        if (Sync.isEnabled) {
            await Sync.loadAll();
        }

        // Initialize modules
        Search.init();
        Editor.init();
        Tasks.init();
        Reminders.init();
        MindMap.init();
        Journal.init();
        Pomodoro.init();

        // Theme switcher
        document.querySelectorAll('.theme-card').forEach(card => {
            card.addEventListener('click', () => {
                this.setTheme(card.dataset.theme);
            });
        });

        // Navigation
        document.querySelectorAll('.nav-item[data-view]').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchView(item.dataset.view);
            });
        });

        // New Page buttons
        document.getElementById('newPageBtn').addEventListener('click', () => Editor.createNewPage());
        document.getElementById('newPageBtnPages').addEventListener('click', () => Editor.createNewPage());

        // Dashboard quick actions
        document.getElementById('quickNewPage').addEventListener('click', () => Editor.createNewPage());
        document.getElementById('quickNewTask').addEventListener('click', () => this.switchView('tasks'));
        document.getElementById('quickSearch').addEventListener('click', () => Search.open());
        document.getElementById('quickMindMap').addEventListener('click', () => this.switchView('mindmap'));
        document.getElementById('quickJournal').addEventListener('click', () => this.switchView('journal'));
        document.getElementById('quickPomodoro').addEventListener('click', () => this.switchView('pomodoro'));

        // Pages filter
        document.getElementById('pagesSearchInput').addEventListener('input', (e) => {
            this.renderAllPages(e.target.value);
        });

        // Quick Capture
        document.getElementById('quickCaptureBtn').addEventListener('click', () => this.openQuickCapture());
        document.getElementById('closeQuickCapture').addEventListener('click', () => this.closeQuickCapture());
        document.getElementById('cancelQuickCapture').addEventListener('click', () => this.closeQuickCapture());
        document.getElementById('saveQuickCapture').addEventListener('click', () => this.saveQuickCapture());
        document.getElementById('quickCaptureInput').addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') this.saveQuickCapture();
        });

        // Editor actions
        document.getElementById('deletePageBtn').addEventListener('click', () => this.deletePage());
        document.getElementById('favPageBtn').addEventListener('click', () => this.toggleFavorite());

        // Trash
        document.getElementById('emptyTrashBtn').addEventListener('click', () => this.emptyTrash());

        // Export / Import
        document.getElementById('exportDataBtn').addEventListener('click', () => this.exportData());
        document.getElementById('importDataBtn').addEventListener('change', (e) => this.importData(e));

        // Confirm Dialog
        document.getElementById('confirmCancel').addEventListener('click', () => this.closeConfirmModal());
        document.getElementById('confirmOk').addEventListener('click', () => {
            if (this.confirmCallback) this.confirmCallback();
            this.closeConfirmModal();
        });

        // Sidebar Logic (Mobile Toggle Only)
        const sidebar = document.getElementById('sidebar');

        // Mobile toggle
        document.getElementById('sidebarToggle').addEventListener('click', (e) => {
            e.stopPropagation();
            sidebar.classList.toggle('visible');
        });

        // Close sidebar on mobile when clicking outside
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 &&
                sidebar.classList.contains('visible') &&
                !sidebar.contains(e.target) &&
                e.target.id !== 'sidebarToggle') {
                sidebar.classList.remove('visible');
            }
        });

        // Global shortcuts
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); /* Auto-save is on */ }
            if (e.key === 'Escape') {
                Search.close();
                Tasks.closeModal();
                this.closeQuickCapture();
                this.closeConfirmModal();
                // Close sidebar only on mobile
                if (window.innerWidth <= 768) sidebar.classList.remove('visible');
            }
            if (e.ctrlKey && e.key === 'k') {
                e.preventDefault();
                Search.open();
            }
            if (e.ctrlKey && e.key === 'n') {
                e.preventDefault();
                Editor.createNewPage();
            }
        });

        // Load sidebar & dashboard
        await this.refreshSidebar();
        await this.renderDashboard();

        // Auto-purge old trash (30 days)
        this._autoPurgeTrash();
    },

    // --- Views ---

    switchView(viewName) {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        const viewEl = document.getElementById(viewName + 'View');
        if (viewEl) viewEl.classList.add('active');

        document.querySelectorAll('.nav-item[data-view]').forEach(item => {
            item.classList.toggle('active', item.dataset.view === viewName);
        });

        this.currentView = viewName;

        if (viewName === 'dashboard') this.renderDashboard();
        if (viewName === 'pages') this.renderAllPages();
        if (viewName === 'tasks') Tasks.render();
        if (viewName === 'reminders') Reminders.render();
        if (viewName === 'journal') Journal.load();
        if (viewName === 'mindmap') setTimeout(() => MindMap.load(), 100);
        if (viewName === 'trash') this.renderTrash();
    },

    openPage(pageId) {
        Editor.loadPage(pageId);
    },

    // --- Dashboard ---

    async renderDashboard() {
        // Greeting
        const hour = new Date().getHours();
        let greeting = 'Good Evening 🌙';
        if (hour < 12) greeting = 'Good Morning 🌅';
        else if (hour < 17) greeting = 'Good Afternoon ☀️';
        document.querySelector('#dashboardGreeting h1').textContent = greeting;
        document.getElementById('dashboardDate').textContent =
            new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

        // Stats
        const pages = await DB.getAllPages();
        const activePages = pages.filter(p => !p.isTrashed);
        const tasks = await DB.getAllTasks();
        const reminders = await DB.getAllReminders();
        const now = new Date();

        document.getElementById('statPages').textContent = activePages.length;
        document.getElementById('statTasks').textContent = tasks.filter(t => t.status !== 'done').length;
        document.getElementById('statReminders').textContent = reminders.filter(r => !r.isCompleted && new Date(r.datetime) > now).length;

        // Streak (count consecutive days with journal entries)
        let streak = 0;
        const d = new Date();
        while (true) {
            const key = `journal-${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
            const entry = await DB.get('pages', key);
            if (entry && entry.content && entry.content.trim().length > 0) {
                streak++;
                d.setDate(d.getDate() - 1);
            } else {
                break;
            }
        }
        document.getElementById('statStreak').textContent = streak;

        // Today's Focus: upcoming tasks + overdue reminders
        const todayStr = now.toISOString().split('T')[0];
        const focusItems = [];

        tasks.filter(t => t.status !== 'done').forEach(t => {
            if (t.dueDate && t.dueDate <= todayStr) {
                focusItems.push({ type: 'task', text: t.title, overdue: t.dueDate < todayStr, priority: t.priority });
            }
        });

        reminders.filter(r => !r.isCompleted).forEach(r => {
            const rDate = new Date(r.datetime);
            if (rDate.toISOString().split('T')[0] <= todayStr) {
                focusItems.push({ type: 'reminder', text: r.title, overdue: rDate < now });
            }
        });

        const focusEl = document.getElementById('todayFocus');
        if (focusItems.length === 0) {
            focusEl.innerHTML = '<div class="empty-state">🎉 All clear! No tasks or reminders due today.</div>';
        } else {
            focusEl.innerHTML = focusItems.map(item => `
                <div class="focus-item ${item.overdue ? 'overdue' : ''}">
                    <span class="focus-icon">${item.type === 'task' ? '✅' : '⏰'}</span>
                    <span class="focus-text">${item.text}</span>
                    ${item.overdue ? '<span class="focus-badge">OVERDUE</span>' : ''}
                    ${item.priority === 'urgent' ? '<span class="focus-badge urgent">URGENT</span>' : ''}
                </div>
            `).join('');
        }

        // Recent pages
        const recentList = document.getElementById('recentList');
        const recent = activePages.filter(p => !p.isJournal).slice(0, 5);
        recentList.innerHTML = recent.length === 0
            ? '<div class="empty-state">No pages yet — create your first!</div>'
            : recent.map(p => `
                <button class="recent-item" onclick="App.openPage('${p.id}')">
                    <span class="recent-icon">${p.icon || '📄'}</span>
                    <div class="recent-info">
                        <span class="recent-title">${p.title || 'Untitled'}</span>
                        <span class="recent-date">${new Date(p.updatedAt).toLocaleDateString()}</span>
                    </div>
                </button>
            `).join('');

        // Favorites
        const favGrid = document.getElementById('favoritesGrid');
        const favs = activePages.filter(p => p.isFavorite);
        favGrid.innerHTML = favs.length === 0
            ? '<div class="empty-state">Star pages to see them here ⭐</div>'
            : favs.map(p => `
                <button class="recent-item" onclick="App.openPage('${p.id}')">
                    <span class="recent-icon">${p.icon || '📄'}</span>
                    <div class="recent-info">
                        <span class="recent-title">${p.title || 'Untitled'}</span>
                    </div>
                </button>
            `).join('');
    },

    // --- Sidebar ---

    async refreshSidebar() {
        const pages = await DB.getAllPages();
        const activePages = pages.filter(p => !p.isTrashed && !p.isJournal);

        // Pages list
        const pagesList = document.getElementById('pagesList');
        pagesList.innerHTML = activePages.slice(0, 15).map(p => `
            <a href="#" class="nav-item nav-page-item" data-page-id="${p.id}">
                <span class="nav-icon">${p.icon || '📄'}</span>
                <span>${p.title || 'Untitled'}</span>
            </a>
        `).join('');

        pagesList.querySelectorAll('.nav-page-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                this.openPage(item.dataset.pageId);
            });
        });

        // Favorites list
        const favList = document.getElementById('favoritesList');
        const favPages = activePages.filter(p => p.isFavorite);
        favList.innerHTML = favPages.length === 0
            ? '<div style="padding: 4px 12px; font-size: 11px; color:var(--text-tertiary);">No favorites yet</div>'
            : favPages.map(p => `
                <a href="#" class="nav-item nav-page-item" data-page-id="${p.id}">
                    <span class="nav-icon">⭐</span>
                    <span>${p.title || 'Untitled'}</span>
                </a>
            `).join('');

        favList.querySelectorAll('.nav-page-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                this.openPage(item.dataset.pageId);
            });
        });

        // Tags
        const allTags = new Set();
        activePages.forEach(p => (p.tags || []).forEach(t => allTags.add(t)));
        const tagsList = document.getElementById('tagsList');
        tagsList.innerHTML = [...allTags].slice(0, 10).map(tag => `
            <span class="tag-badge sidebar-tag" data-tag="${tag}">${tag}</span>
        `).join('');

        tagsList.querySelectorAll('.sidebar-tag').forEach(tag => {
            tag.addEventListener('click', () => {
                this.switchView('pages');
                document.getElementById('pagesSearchInput').value = tag.dataset.tag;
                this.renderAllPages(tag.dataset.tag);
            });
        });
    },

    // --- All Pages ---

    async renderAllPages(filter = '') {
        const pages = await DB.getAllPages();
        const activePages = pages.filter(p => !p.isTrashed && !p.isJournal);
        const q = filter.toLowerCase().trim();
        const filtered = q
            ? activePages.filter(p => (
                (p.title || '').toLowerCase().includes(q) ||
                (p.tags || []).some(t => t.toLowerCase().includes(q))
            ))
            : activePages;

        document.getElementById('pagesCount').textContent = `${filtered.length} page${filtered.length !== 1 ? 's' : ''}`;

        const grid = document.getElementById('pagesGrid');

        if (filtered.length === 0) {
            grid.innerHTML = `
                <div class="pages-empty">
                    <span style="font-size:40px;">📄</span>
                    <p>No pages yet. Create your first one!</p>
                </div>
            `;
            return;
        }

        grid.innerHTML = filtered.map(p => {
            const date = new Date(p.updatedAt).toLocaleDateString();
            const preview = this._stripHtml(p.content).substring(0, 100);
            const tagsHtml = (p.tags || []).map(t => `<span class="tag-badge" style="font-size:10px;padding:1px 6px;">${t}</span>`).join('');
            return `
                <div class="page-card" data-page-id="${p.id}">
                    <div class="page-card-actions">
                        <button class="page-card-fav" onclick="event.stopPropagation(); App.toggleFavFromCard('${p.id}')" title="Toggle Favorite">
                            ${p.isFavorite ? '★' : '☆'}
                        </button>
                        <button class="page-card-del" onclick="event.stopPropagation(); App.deletePageById('${p.id}')" title="Delete">
                            🗑️
                        </button>
                    </div>
                    <div class="page-card-icon">${p.icon || '📄'}</div>
                    <div class="page-card-title">${p.title || 'Untitled'}</div>
                    <div class="page-card-preview">${preview || 'Empty page'}</div>
                    <div class="page-card-meta">
                        <span class="page-card-date">${date}</span>
                        <div class="page-card-tags">${tagsHtml}</div>
                    </div>
                </div>
            `;
        }).join('');

        grid.querySelectorAll('.page-card').forEach(card => {
            card.addEventListener('click', () => {
                this.openPage(card.dataset.pageId);
            });
        });
    },

    // --- Page Delete ---

    async deletePage() {
        const pageId = Editor.currentPageId;
        if (!pageId) return;

        const page = await DB.get('pages', pageId);
        if (!page) return;

        this.confirm(`Delete "${page.title || 'Untitled'}"?`, 'This page will be moved to Trash. You can restore it within 30 days.', async () => {
            page.isTrashed = true;
            page.trashedAt = new Date().toISOString();
            await DB.put('pages', page);
            if (typeof Sync !== 'undefined') Sync.saveStore('pages');
            this.switchView('pages');
            this.refreshSidebar();
        });
    },

    async deletePageById(id) {
        const page = await DB.get('pages', id);
        if (!page) return;

        this.confirm(`Delete "${page.title || 'Untitled'}"?`, 'Move to Trash?', async () => {
            page.isTrashed = true;
            page.trashedAt = new Date().toISOString();
            await DB.put('pages', page);
            if (typeof Sync !== 'undefined') Sync.saveStore('pages');
            this.renderAllPages();
            this.refreshSidebar();
        });
    },

    // --- Favorites ---

    async toggleFavorite() {
        const pageId = Editor.currentPageId;
        if (!pageId) return;
        const page = await DB.get('pages', pageId);
        if (!page) return;

        page.isFavorite = !page.isFavorite;
        await DB.put('pages', page);
        if (typeof Sync !== 'undefined') Sync.saveStore('pages');

        document.getElementById('favPageBtn').textContent = page.isFavorite ? '★' : '☆';
        this.refreshSidebar();
    },

    async toggleFavFromCard(id) {
        const page = await DB.get('pages', id);
        if (!page) return;
        page.isFavorite = !page.isFavorite;
        await DB.put('pages', page);
        if (typeof Sync !== 'undefined') Sync.saveStore('pages');
        this.renderAllPages();
        this.refreshSidebar();
    },

    // --- Trash ---

    async renderTrash() {
        const pages = await DB.getAllPages();
        const trashed = pages.filter(p => p.isTrashed)
            .sort((a, b) => new Date(b.trashedAt) - new Date(a.trashedAt));

        const list = document.getElementById('trashList');

        if (trashed.length === 0) {
            list.innerHTML = '<div class="empty-state" style="text-align:center; padding:48px;">🗑️ Trash is empty</div>';
            return;
        }

        list.innerHTML = trashed.map(p => {
            const date = new Date(p.trashedAt).toLocaleDateString();
            return `
                <div class="trash-item">
                    <span class="trash-item-icon">${p.icon || '📄'}</span>
                    <div class="trash-item-info">
                        <div class="trash-item-title">${p.title || 'Untitled'}</div>
                        <div class="trash-item-date">Deleted ${date}</div>
                    </div>
                    <div class="trash-item-actions">
                        <button class="btn secondary btn-sm" onclick="App.restorePage('${p.id}')">↩ Restore</button>
                        <button class="btn secondary btn-sm btn-danger" onclick="App.permanentDelete('${p.id}')">✕ Delete</button>
                    </div>
                </div>
            `;
        }).join('');
    },

    async restorePage(id) {
        const page = await DB.get('pages', id);
        if (!page) return;
        page.isTrashed = false;
        delete page.trashedAt;
        await DB.put('pages', page);
        if (typeof Sync !== 'undefined') Sync.saveStore('pages');
        this.renderTrash();
        this.refreshSidebar();
    },

    async permanentDelete(id) {
        this.confirm('Permanently delete?', 'This cannot be undone.', async () => {
            await DB.delete('pages', id);
            if (typeof Sync !== 'undefined') Sync.saveStore('pages');
            this.renderTrash();
            this.refreshSidebar();
        });
    },

    async emptyTrash() {
        this.confirm('Empty all trash?', 'All trashed pages will be permanently deleted.', async () => {
            const pages = await DB.getAllPages();
            const trashed = pages.filter(p => p.isTrashed);
            for (const p of trashed) {
                await DB.delete('pages', p.id);
            }
            if (typeof Sync !== 'undefined') Sync.saveStore('pages');
            this.renderTrash();
            this.refreshSidebar();
        });
    },

    _autoPurgeTrash() {
        DB.getAllPages().then(pages => {
            const now = new Date();
            const thirtyDays = 30 * 24 * 60 * 60 * 1000;
            pages.filter(p => p.isTrashed && p.trashedAt).forEach(async p => {
                if (now - new Date(p.trashedAt) > thirtyDays) {
                    await DB.delete('pages', p.id);
                }
            });
        });
    },

    // --- Quick Capture ---

    openQuickCapture() {
        document.getElementById('quickCaptureModal').classList.remove('hidden');
        document.getElementById('quickCaptureInput').value = '';
        document.getElementById('quickCaptureInput').focus();
    },

    closeQuickCapture() {
        document.getElementById('quickCaptureModal').classList.add('hidden');
    },

    async saveQuickCapture() {
        const text = document.getElementById('quickCaptureInput').value.trim();
        if (!text) return;

        const title = text.substring(0, 50) + (text.length > 50 ? '...' : '');
        const content = `<p>${text.replace(/\n/g, '</p><p>')}</p>`;

        const page = await DB.createPage(title, content, '⚡', ['quick-capture']);
        this.closeQuickCapture();
        this.refreshSidebar();

        // Open the page
        Editor.loadPage(page.id);
    },

    // --- Confirm Dialog ---

    confirm(title, message, onConfirm) {
        document.getElementById('confirmTitle').textContent = title;
        document.getElementById('confirmMessage').textContent = message;
        document.getElementById('confirmModal').classList.remove('hidden');

        const okBtn = document.getElementById('confirmOk');
        const cancelBtn = document.getElementById('confirmCancel');

        const cleanup = () => {
            document.getElementById('confirmModal').classList.add('hidden');
            okBtn.replaceWith(okBtn.cloneNode(true));
            cancelBtn.replaceWith(cancelBtn.cloneNode(true));
        };

        document.getElementById('confirmOk').addEventListener('click', () => {
            cleanup();
            onConfirm();
        });

        document.getElementById('confirmCancel').addEventListener('click', cleanup);
    },

    // --- Export / Import ---

    async exportData() {
        const data = await DB.exportAll();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `secondbrain-backup-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(a.href);
    },

    async importData(e) {
        const file = e.target.files[0];
        if (!file) return;

        this.confirm('Import data?', 'This will replace ALL existing data. Make sure you have a backup.', async () => {
            const text = await file.text();
            const data = JSON.parse(text);
            await DB.importAll(data);
            if (typeof Sync !== 'undefined') Sync.saveAll();
            location.reload();
        });
    },

    // --- Helpers ---

    _stripHtml(html) {
        const div = document.createElement('div');
        div.innerHTML = html || '';
        return div.textContent || div.innerText || '';
    },

    // --- Theme ---

    loadTheme() {
        const saved = localStorage.getItem('sb-theme') || 'light';
        document.documentElement.setAttribute('data-theme', saved);
        this._highlightThemeCard(saved);
    },

    setTheme(themeName) {
        document.documentElement.setAttribute('data-theme', themeName);
        localStorage.setItem('sb-theme', themeName);
        this._highlightThemeCard(themeName);
    },

    _highlightThemeCard(themeName) {
        document.querySelectorAll('.theme-card').forEach(card => {
            card.classList.toggle('active', card.dataset.theme === themeName);
        });
    }
};

// --- Boot ---
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
