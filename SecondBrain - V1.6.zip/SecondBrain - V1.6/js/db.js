// ==========================================
// SECOND BRAIN — IndexedDB Wrapper (db.js)
// ==========================================

const DB = {
    name: 'SecondBrainDB',
    version: 2,
    db: null,

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.name, this.version);

            request.onupgradeneeded = (e) => {
                const db = e.target.result;

                // Pages Store
                if (!db.objectStoreNames.contains('pages')) {
                    const pageStore = db.createObjectStore('pages', { keyPath: 'id' });
                    pageStore.createIndex('title', 'title', { unique: false });
                    pageStore.createIndex('updatedAt', 'updatedAt', { unique: false });
                    pageStore.createIndex('parentId', 'parentId', { unique: false });
                }

                // Tasks Store
                if (!db.objectStoreNames.contains('tasks')) {
                    const taskStore = db.createObjectStore('tasks', { keyPath: 'id' });
                    taskStore.createIndex('status', 'status', { unique: false });
                    taskStore.createIndex('priority', 'priority', { unique: false });
                    taskStore.createIndex('dueDate', 'dueDate', { unique: false });
                }

                // Reminders Store
                if (!db.objectStoreNames.contains('reminders')) {
                    const reminderStore = db.createObjectStore('reminders', { keyPath: 'id' });
                    reminderStore.createIndex('datetime', 'datetime', { unique: false });
                    reminderStore.createIndex('isCompleted', 'isCompleted', { unique: false });
                }

                // Tags Store
                if (!db.objectStoreNames.contains('tags')) {
                    db.createObjectStore('tags', { keyPath: 'id' });
                }

                // Mind Map Store
                if (!db.objectStoreNames.contains('mindmaps')) {
                    db.createObjectStore('mindmaps', { keyPath: 'id' });
                }

                // Meta Store (for sync directory handle etc.)
                if (!db.objectStoreNames.contains('_meta')) {
                    db.createObjectStore('_meta', { keyPath: 'id' });
                }
            };

            request.onsuccess = (e) => {
                this.db = e.target.result;
                console.log('🧠 SecondBrain DB initialized');
                resolve(this.db);
            };

            request.onerror = (e) => {
                console.error('DB Error:', e.target.error);
                reject(e.target.error);
            };
        });
    },

    // --- Generic CRUD ---

    _generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
    },

    async add(storeName, data) {
        data.id = data.id || this._generateId();
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.add(data);
            request.onsuccess = () => resolve(data);
            request.onerror = (e) => reject(e.target.error);
        });
    },

    async put(storeName, data) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.put(data);
            request.onsuccess = () => resolve(data);
            request.onerror = (e) => reject(e.target.error);
        });
    },

    async get(storeName, id) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const request = store.get(id);
            request.onsuccess = () => resolve(request.result);
            request.onerror = (e) => reject(e.target.error);
        });
    },

    async getAll(storeName) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const request = store.getAll();
            request.onsuccess = () => resolve(request.result || []);
            request.onerror = (e) => reject(e.target.error);
        });
    },

    async delete(storeName, id) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.delete(id);
            request.onsuccess = () => resolve(true);
            request.onerror = (e) => reject(e.target.error);
        });
    },

    async clear(storeName) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.clear();
            request.onsuccess = () => resolve(true);
            request.onerror = (e) => reject(e.target.error);
        });
    },

    // --- Higher-Level Page Ops ---

    async createPage(title = 'Untitled', content = '', icon = '📄', tags = []) {
        const now = new Date().toISOString();
        const result = await this.add('pages', {
            title, content, icon, tags,
            parentId: null,
            createdAt: now,
            updatedAt: now
        });
        if (typeof Sync !== 'undefined') Sync.saveStore('pages');
        return result;
    },

    async updatePage(id, updates) {
        const page = await this.get('pages', id);
        if (!page) return null;
        Object.assign(page, updates, { updatedAt: new Date().toISOString() });
        const result = await this.put('pages', page);
        if (typeof Sync !== 'undefined') Sync.saveStore('pages');
        return result;
    },

    async getAllPages() {
        const pages = await this.getAll('pages');
        return pages.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    },

    // --- Higher-Level Task Ops ---

    async createTask(title, priority = 'medium', dueDate = '', status = 'todo') {
        const result = await this.add('tasks', {
            title, priority, dueDate, status,
            createdAt: new Date().toISOString()
        });
        if (typeof Sync !== 'undefined') Sync.saveStore('tasks');
        return result;
    },

    async updateTask(id, updates) {
        const task = await this.get('tasks', id);
        if (!task) return null;
        Object.assign(task, updates);
        const result = await this.put('tasks', task);
        if (typeof Sync !== 'undefined') Sync.saveStore('tasks');
        return result;
    },

    async getAllTasks() {
        return this.getAll('tasks');
    },

    // --- Higher-Level Reminder Ops ---

    async createReminder(title, datetime) {
        const result = await this.add('reminders', {
            title, datetime,
            isCompleted: false,
            createdAt: new Date().toISOString()
        });
        if (typeof Sync !== 'undefined') Sync.saveStore('reminders');
        return result;
    },

    async getAllReminders() {
        const reminders = await this.getAll('reminders');
        return reminders.sort((a, b) => new Date(a.datetime) - new Date(b.datetime));
    },

    // --- Export / Import ---

    async exportAll() {
        const [pages, tasks, reminders, tags, mindmaps] = await Promise.all([
            this.getAll('pages'),
            this.getAll('tasks'),
            this.getAll('reminders'),
            this.getAll('tags'),
            this.getAll('mindmaps')
        ]);
        return { pages, tasks, reminders, tags, mindmaps, exportedAt: new Date().toISOString() };
    },

    async importAll(data) {
        // Clear everything first
        await Promise.all([
            this.clear('pages'),
            this.clear('tasks'),
            this.clear('reminders'),
            this.clear('tags'),
            this.clear('mindmaps')
        ]);

        // Import each store
        const stores = ['pages', 'tasks', 'reminders', 'tags', 'mindmaps'];
        for (const store of stores) {
            if (data[store]) {
                for (const item of data[store]) {
                    await this.add(store, item);
                }
            }
        }
        return true;
    }
};
