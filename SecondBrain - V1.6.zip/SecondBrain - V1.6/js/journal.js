// ==========================================
// SECOND BRAIN — Daily Journal (journal.js)
// ==========================================

const Journal = {
    currentDate: null,
    saveTimeout: null,
    body: null,

    init() {
        this.body = document.getElementById('journalBody');
        this.currentDate = this._todayKey();

        document.getElementById('journalPrev').addEventListener('click', () => this.navigate(-1));
        document.getElementById('journalNext').addEventListener('click', () => this.navigate(1));
        document.getElementById('journalToday').addEventListener('click', () => {
            this.currentDate = this._todayKey();
            this.load();
        });

        this.body.addEventListener('input', () => {
            this._updateWordCount();
            this._scheduleSave();
        });
    },

    _todayKey() {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    },

    _formatDate(dateKey) {
        const d = new Date(dateKey + 'T12:00:00');
        return d.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    },

    navigate(direction) {
        const d = new Date(this.currentDate + 'T12:00:00');
        d.setDate(d.getDate() + direction);
        this.currentDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        this.load();
    },

    async load() {
        const label = document.getElementById('journalDateLabel');
        const isToday = this.currentDate === this._todayKey();
        label.textContent = isToday ? '📅 Today' : this._formatDate(this.currentDate);

        // Try to find existing journal page for this date
        const pages = await DB.getAllPages();
        const journalId = `journal-${this.currentDate}`;
        let page = pages.find(p => p.id === journalId);

        if (!page) {
            // Create journal entry
            const title = `Journal — ${this._formatDate(this.currentDate)}`;
            page = {
                id: journalId,
                title: title,
                content: '',
                icon: '📓',
                tags: ['journal'],
                parentId: null,
                isJournal: true,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            await DB.put('pages', page);
            if (typeof Sync !== 'undefined') Sync.saveStore('pages');
        }

        this.body.innerHTML = page.content || '';
        this._updateWordCount();

        const indicator = document.getElementById('journalSaveIndicator');
        indicator.textContent = 'Ready';
        indicator.style.color = 'var(--text-tertiary)';
    },

    async save() {
        const journalId = `journal-${this.currentDate}`;
        const page = await DB.get('pages', journalId);
        if (!page) return;

        page.content = this.body.innerHTML;
        page.updatedAt = new Date().toISOString();
        await DB.put('pages', page);
        if (typeof Sync !== 'undefined') Sync.saveStore('pages');

        const indicator = document.getElementById('journalSaveIndicator');
        indicator.textContent = 'Saved ✓';
        indicator.style.color = 'var(--success)';
    },

    _scheduleSave() {
        clearTimeout(this.saveTimeout);
        const indicator = document.getElementById('journalSaveIndicator');
        indicator.textContent = 'Editing...';
        indicator.style.color = 'var(--text-tertiary)';
        this.saveTimeout = setTimeout(() => this.save(), 800);
    },

    _updateWordCount() {
        const text = this.body.innerText || '';
        const words = text.trim().split(/\s+/).filter(w => w.length > 0).length;
        document.getElementById('journalWordCount').textContent = `${words} word${words !== 1 ? 's' : ''}`;
    }
};
