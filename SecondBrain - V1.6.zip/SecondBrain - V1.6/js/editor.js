// ==========================================
// SECOND BRAIN — Editor Module (editor.js)
// ==========================================

const Editor = {
    currentPageId: null,
    saveTimeout: null,
    body: null,
    title: null,

    init() {
        this.body = document.getElementById('editorBody');
        this.title = document.getElementById('editorTitle');

        // Toolbar commands
        document.querySelectorAll('.toolbar-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const cmd = btn.dataset.cmd;
                this.execCommand(cmd);
            });
        });

        // Auto-save on content change
        this.body.addEventListener('input', () => {
            this._updateWordCount();
            this._scheduleSave();
        });

        this.title.addEventListener('input', () => {
            this._scheduleSave();
        });

        // Tag input
        document.getElementById('tagInput').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const tag = e.target.value.trim();
                if (tag) {
                    this.addTag(tag);
                    e.target.value = '';
                }
            }
        });

        // Keyboard shortcuts inside editor
        this.body.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                switch (e.key) {
                    case 'b': e.preventDefault(); this.execCommand('bold'); break;
                    case 'i': e.preventDefault(); this.execCommand('italic'); break;
                    case 'u': e.preventDefault(); this.execCommand('underline'); break;
                    case 's': e.preventDefault(); this.save(); break;
                }
            }
        });
    },

    execCommand(cmd) {
        switch (cmd) {
            case 'bold': document.execCommand('bold'); break;
            case 'italic': document.execCommand('italic'); break;
            case 'underline': document.execCommand('underline'); break;
            case 'h1': document.execCommand('formatBlock', false, '<h1>'); break;
            case 'h2': document.execCommand('formatBlock', false, '<h2>'); break;
            case 'h3': document.execCommand('formatBlock', false, '<h3>'); break;
            case 'ul': document.execCommand('insertUnorderedList'); break;
            case 'ol': document.execCommand('insertOrderedList'); break;
            case 'quote': document.execCommand('formatBlock', false, '<blockquote>'); break;
            case 'code':
                document.execCommand('formatBlock', false, '<pre>');
                break;
            case 'hr':
                document.execCommand('insertHorizontalRule');
                break;
        }
        this.body.focus();
    },

    async loadPage(pageId) {
        const page = await DB.get('pages', pageId);
        if (!page) return;

        this.currentPageId = pageId;
        this.title.value = page.title;
        this.body.innerHTML = page.content || '';
        document.getElementById('pageIconBtn').textContent = page.icon || '📄';

        // Update favorite button
        document.getElementById('favPageBtn').textContent = page.isFavorite ? '★' : '☆';

        // Render tags
        this._renderTags(page.tags || []);
        this._updateWordCount();
        this._showSaved();

        App.switchView('editor');
    },

    async createNewPage() {
        const page = await DB.createPage();
        await this.loadPage(page.id);
        this.title.focus();
        this.title.select();
        App.refreshSidebar();
        return page;
    },

    async save() {
        if (!this.currentPageId) return;

        const indicator = document.getElementById('saveIndicator');
        indicator.textContent = 'Saving...';
        indicator.style.color = 'var(--warning)';

        await DB.updatePage(this.currentPageId, {
            title: this.title.value || 'Untitled',
            content: this.body.innerHTML,
        });

        this._showSaved();
        App.refreshSidebar();
    },

    _scheduleSave() {
        clearTimeout(this.saveTimeout);
        const indicator = document.getElementById('saveIndicator');
        indicator.textContent = 'Editing...';
        indicator.style.color = 'var(--text-tertiary)';

        this.saveTimeout = setTimeout(() => this.save(), 800);
    },

    _showSaved() {
        const indicator = document.getElementById('saveIndicator');
        indicator.textContent = 'Saved ✓';
        indicator.style.color = 'var(--success)';
    },

    _updateWordCount() {
        const text = this.body.innerText || '';
        const words = text.trim().split(/\s+/).filter(w => w.length > 0).length;
        document.getElementById('wordCount').textContent = `${words} word${words !== 1 ? 's' : ''}`;
    },

    // --- Tags ---

    async addTag(tagName) {
        if (!this.currentPageId) return;
        const page = await DB.get('pages', this.currentPageId);
        if (!page) return;
        const tags = page.tags || [];
        if (!tags.includes(tagName)) {
            tags.push(tagName);
            await DB.updatePage(this.currentPageId, { tags });
            this._renderTags(tags);
            App.refreshSidebar();
        }
    },

    async removeTag(tagName) {
        if (!this.currentPageId) return;
        const page = await DB.get('pages', this.currentPageId);
        if (!page) return;
        const tags = (page.tags || []).filter(t => t !== tagName);
        await DB.updatePage(this.currentPageId, { tags });
        this._renderTags(tags);
        App.refreshSidebar();
    },

    _renderTags(tags) {
        const container = document.getElementById('editorTags');
        container.innerHTML = tags.map(tag => `
            <span class="tag-badge">
                ${tag}
                <span class="tag-remove" data-tag="${tag}">✕</span>
            </span>
        `).join('');

        container.querySelectorAll('.tag-remove').forEach(btn => {
            btn.addEventListener('click', () => this.removeTag(btn.dataset.tag));
        });
    }
};
