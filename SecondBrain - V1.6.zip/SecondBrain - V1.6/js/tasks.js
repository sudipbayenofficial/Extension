// ==========================================
// SECOND BRAIN — Tasks Module (tasks.js)
// ==========================================

const Tasks = {
    currentFilter: 'all',
    currentView: 'list',
    editingTaskId: null,

    init() {
        // New Task button
        document.getElementById('newTaskBtn').addEventListener('click', () => this.openModal());

        // Modal controls
        document.getElementById('saveTaskBtn').addEventListener('click', () => this.saveTask());
        document.getElementById('cancelTaskBtn').addEventListener('click', () => this.closeModal());
        document.getElementById('closeTaskModal').addEventListener('click', () => this.closeModal());

        // Filter chips
        document.querySelectorAll('.filter-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                this.currentFilter = chip.dataset.status;
                this.render();
            });
        });

        // View toggle
        document.querySelectorAll('.toggle-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentView = btn.dataset.taskView;
                this._toggleView();
                this.render();
            });
        });
    },

    openModal(taskId = null) {
        this.editingTaskId = taskId;
        const modal = document.getElementById('taskModal');
        const title = document.getElementById('taskModalTitle');

        if (taskId) {
            title.textContent = 'Edit Task';
            DB.get('tasks', taskId).then(task => {
                if (task) {
                    document.getElementById('taskTitleInput').value = task.title;
                    document.getElementById('taskPriorityInput').value = task.priority;
                    document.getElementById('taskDueDateInput').value = task.dueDate || '';
                    document.getElementById('taskStatusInput').value = task.status;
                }
            });
        } else {
            title.textContent = 'New Task';
            document.getElementById('taskTitleInput').value = '';
            document.getElementById('taskPriorityInput').value = 'medium';
            document.getElementById('taskDueDateInput').value = '';
            document.getElementById('taskStatusInput').value = 'todo';
        }

        modal.classList.remove('hidden');
        document.getElementById('taskTitleInput').focus();
    },

    closeModal() {
        document.getElementById('taskModal').classList.add('hidden');
        this.editingTaskId = null;
    },

    async saveTask() {
        const title = document.getElementById('taskTitleInput').value.trim();
        if (!title) return;

        const data = {
            title,
            priority: document.getElementById('taskPriorityInput').value,
            dueDate: document.getElementById('taskDueDateInput').value,
            status: document.getElementById('taskStatusInput').value
        };

        if (this.editingTaskId) {
            await DB.updateTask(this.editingTaskId, data);
        } else {
            await DB.createTask(data.title, data.priority, data.dueDate, data.status);
        }

        this.closeModal();
        this.render();
    },

    async render() {
        let tasks = await DB.getAllTasks();

        // Filter
        if (this.currentFilter !== 'all') {
            tasks = tasks.filter(t => t.status === this.currentFilter);
        }

        if (this.currentView === 'list') {
            this._renderList(tasks);
        } else {
            this._renderKanban(tasks);
        }
    },

    _toggleView() {
        const listView = document.getElementById('taskListView');
        const kanbanView = document.getElementById('taskKanbanView');

        if (this.currentView === 'list') {
            listView.classList.remove('hidden');
            kanbanView.classList.add('hidden');
        } else {
            listView.classList.add('hidden');
            kanbanView.classList.remove('hidden');
        }
    },

    _renderList(tasks) {
        const container = document.getElementById('taskList');

        if (tasks.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; padding:48px; color:var(--text-tertiary);">
                    <div style="font-size:32px; margin-bottom:8px;">📋</div>
                    <p>No tasks yet. Create one!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = tasks.map(task => {
            const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'done';
            const dueText = task.dueDate ? new Date(task.dueDate).toLocaleDateString() : '';

            return `
                <div class="task-item" data-id="${task.id}">
                    <input type="checkbox" class="task-checkbox" ${task.status === 'done' ? 'checked' : ''} 
                           onchange="Tasks.toggleDone('${task.id}')">
                    <span class="task-title ${task.status === 'done' ? 'completed' : ''}">${task.title}</span>
                    <span class="task-priority priority-${task.priority}">${task.priority}</span>
                    ${dueText ? `<span class="task-due ${isOverdue ? 'overdue' : ''}">${dueText}</span>` : ''}
                    <button class="task-delete" onclick="Tasks.deleteTask('${task.id}')">✕</button>
                </div>
            `;
        }).join('');

        // Click to edit
        container.querySelectorAll('.task-item').forEach(item => {
            item.addEventListener('dblclick', () => {
                this.openModal(item.dataset.id);
            });
        });
    },

    _renderKanban(allTasks) {
        // For kanban, ignore the filter and show all but sorted
        DB.getAllTasks().then(tasks => {
            const groups = { 'todo': [], 'in-progress': [], 'done': [] };
            tasks.forEach(t => {
                if (groups[t.status]) groups[t.status].push(t);
            });

            Object.keys(groups).forEach(status => {
                const containerId = status === 'todo' ? 'kanbanTodo' :
                    status === 'in-progress' ? 'kanbanProgress' : 'kanbanDone';
                const container = document.getElementById(containerId);

                container.innerHTML = groups[status].map(task => `
                    <div class="kanban-card" data-id="${task.id}" draggable="true">
                        <div class="task-title">${task.title}</div>
                        <div class="kanban-card-meta">
                            <span class="task-priority priority-${task.priority}">${task.priority}</span>
                            ${task.dueDate ? `<span class="task-due">${new Date(task.dueDate).toLocaleDateString()}</span>` : ''}
                        </div>
                    </div>
                `).join('');
            });
        });
    },

    async toggleDone(id) {
        const task = await DB.get('tasks', id);
        if (!task) return;
        task.status = task.status === 'done' ? 'todo' : 'done';
        await DB.put('tasks', task);
        this.render();
    },

    async deleteTask(id) {
        if (!confirm('Delete this task?')) return;
        await DB.delete('tasks', id);
        this.render();
    }
};
