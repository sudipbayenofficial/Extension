// ==========================================
// SECOND BRAIN — Search Module (search.js)
// ==========================================

const Search = {
    modal: null,
    input: null,
    results: null,

    init() {
        this.modal = document.getElementById('searchModal');
        this.input = document.getElementById('globalSearchInput');
        this.results = document.getElementById('searchResults');

        // Keyboard shortcut Ctrl+K
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                this.open();
            }
            if (e.key === 'Escape' && !this.modal.classList.contains('hidden')) {
                this.close();
            }
        });

        // Search on type
        this.input.addEventListener('input', (e) => {
            this.search(e.target.value);
        });

        // Click outside to close
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) this.close();
        });

        // Trigger buttons
        document.getElementById('searchTrigger').addEventListener('click', () => this.open());
    },

    open() {
        this.modal.classList.remove('hidden');
        this.input.value = '';
        this.input.focus();
        this.results.innerHTML = '<div class="search-empty">Start typing to search your brain...</div>';
    },

    close() {
        this.modal.classList.add('hidden');
        this.input.value = '';
    },

    async search(query) {
        if (!query || query.length < 2) {
            this.results.innerHTML = '<div class="search-empty">Start typing to search your brain...</div>';
            return;
        }

        const q = query.toLowerCase();
        const [pages, tasks] = await Promise.all([
            DB.getAllPages(),
            DB.getAllTasks()
        ]);

        let results = [];

        // Search Pages
        pages.forEach(page => {
            const titleMatch = page.title.toLowerCase().includes(q);
            const contentMatch = this._stripHtml(page.content).toLowerCase().includes(q);
            const tagMatch = (page.tags || []).some(t => t.toLowerCase().includes(q));

            if (titleMatch || contentMatch || tagMatch) {
                results.push({
                    type: 'page',
                    icon: page.icon || '📄',
                    title: page.title,
                    preview: this._getPreview(page.content, q),
                    id: page.id
                });
            }
        });

        // Search Tasks
        tasks.forEach(task => {
            if (task.title.toLowerCase().includes(q)) {
                results.push({
                    type: 'task',
                    icon: '✅',
                    title: task.title,
                    preview: `${task.status} · ${task.priority}`,
                    id: task.id
                });
            }
        });

        this._renderResults(results);
    },

    _stripHtml(html) {
        const tmp = document.createElement('div');
        tmp.innerHTML = html || '';
        return tmp.textContent || '';
    },

    _getPreview(content, query) {
        const text = this._stripHtml(content);
        const idx = text.toLowerCase().indexOf(query);
        if (idx === -1) return text.substring(0, 80) + '...';
        const start = Math.max(0, idx - 30);
        const end = Math.min(text.length, idx + 50);
        return '...' + text.substring(start, end) + '...';
    },

    _renderResults(results) {
        if (results.length === 0) {
            this.results.innerHTML = '<div class="search-empty">No results found.</div>';
            return;
        }

        this.results.innerHTML = results.map(r => `
            <button class="search-result-item" data-type="${r.type}" data-id="${r.id}">
                <span class="result-icon">${r.icon}</span>
                <div class="result-info">
                    <div class="result-title">${r.title}</div>
                    <div class="result-preview">${r.preview}</div>
                </div>
                <span class="result-type">${r.type}</span>
            </button>
        `).join('');

        // Click handlers
        this.results.querySelectorAll('.search-result-item').forEach(item => {
            item.addEventListener('click', () => {
                const type = item.dataset.type;
                const id = item.dataset.id;
                this.close();

                if (type === 'page') {
                    App.openPage(id);
                } else if (type === 'task') {
                    App.switchView('tasks');
                }
            });
        });
    }
};
