// ==========================================
// SECOND BRAIN — Reminders Module (reminders.js)
// ==========================================

const Reminders = {
    _checkInterval: null,

    init() {
        document.getElementById('newReminderBtn').addEventListener('click', () => this.openModal());
        document.getElementById('saveReminderBtn').addEventListener('click', () => this.saveReminder());
        document.getElementById('cancelReminderBtn').addEventListener('click', () => this.closeModal());
        document.getElementById('closeReminderModal').addEventListener('click', () => this.closeModal());

        // Try requesting notification permission on first user click
        document.addEventListener('click', () => {
            try {
                if ('Notification' in window && Notification.permission === 'default') {
                    Notification.requestPermission();
                }
            } catch (e) { /* file:// protocol may block this */ }
        }, { once: true });

        // Build the toast container once
        this._createToastContainer();

        // Check reminders immediately, then every 10 seconds
        setTimeout(() => this.checkReminders(), 1000);
        this._checkInterval = setInterval(() => this.checkReminders(), 10000);
    },

    // --- Modal ---

    openModal() {
        const modal = document.getElementById('reminderModal');
        document.getElementById('reminderTitleInput').value = '';
        document.getElementById('reminderDateInput').value = '';
        modal.classList.remove('hidden');
        document.getElementById('reminderTitleInput').focus();
    },

    closeModal() {
        document.getElementById('reminderModal').classList.add('hidden');
    },

    // --- CRUD ---

    async saveReminder() {
        const title = document.getElementById('reminderTitleInput').value.trim();
        const datetime = document.getElementById('reminderDateInput').value;
        if (!title || !datetime) return;

        await DB.createReminder(title, datetime);
        this.closeModal();
        this.render();
    },

    async complete(id) {
        const reminder = await DB.get('reminders', id);
        if (reminder) {
            reminder.isCompleted = true;
            await DB.put('reminders', reminder);
            if (typeof Sync !== 'undefined') Sync.saveStore('reminders');
            this.render();
        }
    },

    async deleteReminder(id) {
        await DB.delete('reminders', id);
        if (typeof Sync !== 'undefined') Sync.saveStore('reminders');
        this.render();
    },

    // --- Render List ---

    async render() {
        const reminders = await DB.getAllReminders();
        const container = document.getElementById('remindersList');

        if (reminders.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; padding:48px; color:var(--text-tertiary);">
                    <div style="font-size:32px; margin-bottom:8px;">⏰</div>
                    <p>No reminders set. Stay on top of things!</p>
                </div>
            `;
            return;
        }

        const now = new Date();

        container.innerHTML = reminders.map(r => {
            const dt = new Date(r.datetime);
            const isPast = dt < now;
            const timeStr = dt.toLocaleString();
            const isOverdue = isPast && !r.isCompleted;

            return `
                <div class="reminder-item" style="${r.isCompleted ? 'opacity:0.5;' : ''}${isOverdue ? 'border-left: 3px solid var(--danger);' : ''}">
                    <span class="reminder-icon" style="${r.isCompleted ? 'opacity:0.4' : ''}">${r.isCompleted ? '✅' : (isPast ? '🔴' : '⏰')}</span>
                    <div class="reminder-info">
                        <div class="reminder-title" style="${r.isCompleted ? 'text-decoration:line-through;' : ''}">${r.title}</div>
                        <div class="reminder-time" style="${isOverdue ? 'color:var(--danger);font-weight:600;' : ''}">${timeStr}${isOverdue ? ' — OVERDUE' : ''}</div>
                    </div>
                    <div class="reminder-actions">
                        ${!r.isCompleted ? `<button class="btn secondary" onclick="Reminders.complete('${r.id}')">Done</button>` : ''}
                        <button class="btn secondary" onclick="Reminders.deleteReminder('${r.id}')" style="color:var(--danger);">✕</button>
                    </div>
                </div>
            `;
        }).join('');
    },

    // --- Check & Notify ---

    async checkReminders() {
        let reminders;
        try {
            reminders = await DB.getAllReminders();
        } catch (e) {
            return; // DB might not be ready yet
        }

        const now = new Date();

        for (const r of reminders) {
            if (r.isCompleted || r.notified) continue;

            const dt = new Date(r.datetime);

            if (dt <= now) {
                // --- ALWAYS show in-app notification ---
                this._showToast(r.title, r.id);

                // --- Also try browser notification (bonus, may not work on file://) ---
                this._tryBrowserNotification(r.title, r.id);

                // --- Play a sound ---
                this._playAlertSound();

                // Mark as notified
                r.notified = true;
                await DB.put('reminders', r);
            }
        }

        if (typeof Sync !== 'undefined') Sync.saveStore('reminders');
    },

    // --- Browser Notification (best-effort) ---

    _tryBrowserNotification(title, id) {
        try {
            if ('Notification' in window && Notification.permission === 'granted') {
                new Notification('⏰ Reminder', {
                    body: title,
                    tag: 'sb-reminder-' + id
                });
            }
        } catch (e) {
            // Silently fail — in-app toast is the primary notification
        }
    },

    // --- In-App Toast (GUARANTEED to work) ---

    _createToastContainer() {
        if (document.getElementById('reminderToastBox')) return;

        const box = document.createElement('div');
        box.id = 'reminderToastBox';
        box.style.cssText = `
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            pointer-events: none;
        `;
        document.body.appendChild(box);
    },

    _showToast(message, id) {
        const box = document.getElementById('reminderToastBox');
        if (!box) return;

        const toast = document.createElement('div');
        toast.className = 'reminder-toast';
        toast.setAttribute('data-reminder-id', id);
        toast.style.cssText = `
            pointer-events: auto;
            background: #1e293b;
            color: #f1f5f9;
            border: 1px solid #ef4444;
            border-left: 4px solid #ef4444;
            border-radius: 12px;
            padding: 16px 20px;
            max-width: 360px;
            min-width: 280px;
            box-shadow: 0 12px 40px rgba(0,0,0,0.5), 0 0 20px rgba(239,68,68,0.2);
            font-family: 'Inter', -apple-system, sans-serif;
            font-size: 14px;
            cursor: pointer;
            opacity: 0;
            transform: translateX(40px);
            transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        `;

        toast.innerHTML = `
            <div style="display:flex; align-items:center; gap:10px; margin-bottom:6px;">
                <span style="font-size:20px; animation: pulse 1s infinite;">⏰</span>
                <strong style="font-size:13px; text-transform:uppercase; letter-spacing:0.5px; color:#ef4444;">Reminder Due!</strong>
                <span style="margin-left:auto; opacity:0.5; font-size:16px;" onclick="event.stopPropagation(); this.parentElement.parentElement.remove();">✕</span>
            </div>
            <div style="font-size:15px; font-weight:500; line-height:1.4;">${message}</div>
            <div style="font-size:11px; color:#94a3b8; margin-top:6px;">Click to view reminders</div>
        `;

        // Click to go to reminders view
        toast.addEventListener('click', () => {
            toast.remove();
            App.switchView('reminders');
        });

        box.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                toast.style.opacity = '1';
                toast.style.transform = 'translateX(0)';
            });
        });

        // Auto-dismiss after 30 seconds
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(40px)';
            setTimeout(() => toast.remove(), 400);
        }, 30000);
    },

    // --- Alert Sound (Web Audio API — no files needed) ---

    _playAlertSound() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();

            // Play two short beeps
            [0, 0.25].forEach(startOffset => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();

                osc.connect(gain);
                gain.connect(ctx.destination);

                osc.type = 'sine';
                osc.frequency.setValueAtTime(880, ctx.currentTime + startOffset);  // A5 note

                gain.gain.setValueAtTime(0, ctx.currentTime + startOffset);
                gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + startOffset + 0.02);
                gain.gain.linearRampToValueAtTime(0, ctx.currentTime + startOffset + 0.15);

                osc.start(ctx.currentTime + startOffset);
                osc.stop(ctx.currentTime + startOffset + 0.2);
            });

            // Close audio context after sounds finish
            setTimeout(() => ctx.close(), 1000);
        } catch (e) {
            // Audio might not be available — that's fine
        }
    }
};
