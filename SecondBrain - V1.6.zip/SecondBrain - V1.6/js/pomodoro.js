// ==========================================
// SECOND BRAIN — Pomodoro Focus Timer (pomodoro.js)
// ==========================================

const Pomodoro = {
    workMinutes: 25,
    breakMinutes: 5,
    timeLeft: 25 * 60,
    isRunning: false,
    isBreak: false,
    interval: null,
    sessions: 0,
    totalMinutes: 0,

    init() {
        document.getElementById('pomodoroStartBtn').addEventListener('click', () => this.toggleTimer());
        document.getElementById('pomodoroResetBtn').addEventListener('click', () => this.reset());

        document.getElementById('pomodoroWorkMin').addEventListener('change', (e) => {
            this.workMinutes = parseInt(e.target.value) || 25;
            if (!this.isRunning && !this.isBreak) {
                this.timeLeft = this.workMinutes * 60;
                this._updateDisplay();
            }
        });

        document.getElementById('pomodoroBreakMin').addEventListener('change', (e) => {
            this.breakMinutes = parseInt(e.target.value) || 5;
        });

        // Load today's stats
        this._loadStats();
        this._updateDisplay();
        this._updateProgress();
    },

    toggleTimer() {
        if (this.isRunning) {
            this.pause();
        } else {
            this.start();
        }
    },

    start() {
        this.isRunning = true;
        document.getElementById('pomodoroStartBtn').textContent = '⏸ Pause';
        document.getElementById('pomodoroStartBtn').classList.add('active');

        this.interval = setInterval(() => {
            this.timeLeft--;

            if (this.timeLeft <= 0) {
                this._onComplete();
                return;
            }

            this._updateDisplay();
            this._updateProgress();
        }, 1000);
    },

    pause() {
        this.isRunning = false;
        clearInterval(this.interval);
        document.getElementById('pomodoroStartBtn').textContent = '▶ Resume';
        document.getElementById('pomodoroStartBtn').classList.remove('active');
    },

    reset() {
        this.isRunning = false;
        this.isBreak = false;
        clearInterval(this.interval);
        this.timeLeft = this.workMinutes * 60;

        document.getElementById('pomodoroStartBtn').textContent = '▶ Start';
        document.getElementById('pomodoroStartBtn').classList.remove('active');
        document.getElementById('pomodoroLabel').textContent = 'Focus Time';
        document.getElementById('pomodoroRing').classList.remove('break-mode');

        this._updateDisplay();
        this._updateProgress();
    },

    _onComplete() {
        clearInterval(this.interval);
        this.isRunning = false;
        this._playSound();

        if (!this.isBreak) {
            // Work session completed
            this.sessions++;
            this.totalMinutes += this.workMinutes;
            this._saveStats();
            this._updateStats();

            // Switch to break
            this.isBreak = true;
            this.timeLeft = this.breakMinutes * 60;
            document.getElementById('pomodoroLabel').textContent = '☕ Break Time';
            document.getElementById('pomodoroStartBtn').textContent = '▶ Start Break';
            document.getElementById('pomodoroRing').classList.add('break-mode');
        } else {
            // Break completed — back to work
            this.isBreak = false;
            this.timeLeft = this.workMinutes * 60;
            document.getElementById('pomodoroLabel').textContent = 'Focus Time';
            document.getElementById('pomodoroStartBtn').textContent = '▶ Start';
            document.getElementById('pomodoroRing').classList.remove('break-mode');
        }

        this._updateDisplay();
        this._updateProgress();
    },

    _updateDisplay() {
        const mins = Math.floor(this.timeLeft / 60);
        const secs = this.timeLeft % 60;
        document.getElementById('pomodoroTime').textContent =
            `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    },

    _updateProgress() {
        const total = this.isBreak ? this.breakMinutes * 60 : this.workMinutes * 60;
        const progress = 1 - (this.timeLeft / total);
        const circle = document.getElementById('pomodoroProgress');
        const circumference = 2 * Math.PI * 90;
        circle.style.strokeDasharray = circumference;
        circle.style.strokeDashoffset = circumference * (1 - progress);
    },

    _updateStats() {
        document.getElementById('pomodoroSessions').textContent = this.sessions;
        document.getElementById('pomodoroTotal').textContent = `${this.totalMinutes}m`;
    },

    _todayKey() {
        return new Date().toISOString().split('T')[0];
    },

    _saveStats() {
        const key = `pomodoro-${this._todayKey()}`;
        localStorage.setItem(key, JSON.stringify({
            sessions: this.sessions,
            totalMinutes: this.totalMinutes
        }));
    },

    _loadStats() {
        const key = `pomodoro-${this._todayKey()}`;
        const saved = localStorage.getItem(key);
        if (saved) {
            const data = JSON.parse(saved);
            this.sessions = data.sessions || 0;
            this.totalMinutes = data.totalMinutes || 0;
        }
        this._updateStats();
    },

    _playSound() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            // Three ascending tones
            [0, 0.2, 0.4].forEach((offset, i) => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.type = 'sine';
                osc.frequency.setValueAtTime(660 + i * 220, ctx.currentTime + offset);
                gain.gain.setValueAtTime(0, ctx.currentTime + offset);
                gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + offset + 0.02);
                gain.gain.linearRampToValueAtTime(0, ctx.currentTime + offset + 0.2);
                osc.start(ctx.currentTime + offset);
                osc.stop(ctx.currentTime + offset + 0.25);
            });
            setTimeout(() => ctx.close(), 2000);
        } catch (e) { }
    }
};
