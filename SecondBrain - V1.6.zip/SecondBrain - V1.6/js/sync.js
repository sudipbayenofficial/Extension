// ==========================================
// SECOND BRAIN — Directory Sync (sync.js)
// Uses File System Access API (Chrome/Edge)
// ==========================================

const Sync = {
    dirHandle: null,
    isEnabled: false,
    DB_HANDLE_KEY: 'syncDirHandle',

    // File names in the sync directory
    FILES: {
        pages: 'secondbrain-pages.json',
        tasks: 'secondbrain-tasks.json',
        reminders: 'secondbrain-reminders.json',
        mindmaps: 'secondbrain-mindmaps.json',
        tags: 'secondbrain-tags.json'
    },

    isSupported() {
        return 'showDirectoryPicker' in window;
    },

    async init() {
        if (!this.isSupported()) return;

        // Try to restore saved directory handle from IndexedDB
        try {
            const saved = await DB.get('_meta', this.DB_HANDLE_KEY);
            if (saved && saved.handle) {
                this.dirHandle = saved.handle;

                // Verify permission (may prompt user)
                const perm = await this.dirHandle.queryPermission({ mode: 'readwrite' });
                if (perm === 'granted') {
                    this.isEnabled = true;
                    this._updateUI(true);
                } else {
                    // Permission not yet granted — user needs to re-grant
                    this._updateUI(false, 'Click "Re-grant Access" to reconnect');
                }
            }
        } catch (e) {
            console.log('No saved sync directory');
        }
    },

    async pickDirectory() {
        if (!this.isSupported()) {
            alert('Directory sync requires Chrome or Edge browser.');
            return;
        }

        try {
            this.dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
            this.isEnabled = true;

            // Save the handle in a special IndexedDB store
            await this._ensureMetaStore();
            await DB.put('_meta', { id: this.DB_HANDLE_KEY, handle: this.dirHandle });

            // Do an initial full save
            await this.saveAll();
            this._updateUI(true);

        } catch (e) {
            if (e.name === 'AbortError') return; // User cancelled
            console.error('Directory pick failed:', e);
            alert('Failed to set directory: ' + e.message);
        }
    },

    async regrantAccess() {
        if (!this.dirHandle) return;
        try {
            const perm = await this.dirHandle.requestPermission({ mode: 'readwrite' });
            if (perm === 'granted') {
                this.isEnabled = true;
                this._updateUI(true);
                await this.loadAll();
            }
        } catch (e) {
            console.error('Re-grant failed:', e);
        }
    },

    async disconnect() {
        this.dirHandle = null;
        this.isEnabled = false;
        try { await DB.delete('_meta', this.DB_HANDLE_KEY); } catch (e) { }
        this._updateUI(false);
    },

    // --- Write a single store to file ---

    async saveStore(storeName) {
        if (!this.isEnabled || !this.dirHandle) return;

        try {
            const data = await DB.getAll(storeName);
            const fileName = this.FILES[storeName];
            if (!fileName) return;

            const fileHandle = await this.dirHandle.getFileHandle(fileName, { create: true });
            const writable = await fileHandle.createWritable();
            await writable.write(JSON.stringify(data, null, 2));
            await writable.close();
        } catch (e) {
            console.warn(`Sync write failed for ${storeName}:`, e);
        }
    },

    // --- Save All to directory ---

    async saveAll() {
        if (!this.isEnabled || !this.dirHandle) return;

        const stores = Object.keys(this.FILES);
        for (const store of stores) {
            await this.saveStore(store);
        }
        this._flashStatus('Saved to directory ✓');
    },

    // --- Load a single store from file ---

    async loadStore(storeName) {
        if (!this.dirHandle) return false;

        try {
            const fileName = this.FILES[storeName];
            if (!fileName) return false;

            const fileHandle = await this.dirHandle.getFileHandle(fileName);
            const file = await fileHandle.getFile();
            const text = await file.text();
            const data = JSON.parse(text);

            if (!Array.isArray(data)) return false;

            // Clear and re-populate
            await DB.clear(storeName);
            for (const item of data) {
                await DB.put(storeName, item);
            }
            return true;
        } catch (e) {
            // File might not exist yet — that's fine
            if (e.name === 'NotFoundError') return false;
            console.warn(`Sync read failed for ${storeName}:`, e);
            return false;
        }
    },

    // --- Load All from directory ---

    async loadAll() {
        if (!this.isEnabled || !this.dirHandle) return;

        let loaded = false;
        const stores = Object.keys(this.FILES);
        for (const store of stores) {
            const ok = await this.loadStore(store);
            if (ok) loaded = true;
        }

        if (loaded) {
            this._flashStatus('Loaded from directory ✓');
            // Refresh the UI
            await App.refreshSidebar();
            if (App.currentView === 'dashboard') App.renderDashboard();
            if (App.currentView === 'pages') App.renderAllPages();
            if (App.currentView === 'tasks') Tasks.render();
            if (App.currentView === 'reminders') Reminders.render();
        }
    },

    // --- Ensure the _meta object store exists ---

    async _ensureMetaStore() {
        // _meta store is now part of the initial DB schema (v2)
        // No dynamic upgrade needed
    },

    // --- UI Helpers ---

    _updateUI(connected, message = '') {
        const statusEl = document.getElementById('syncStatus');
        const dirNameEl = document.getElementById('syncDirName');
        const pickBtn = document.getElementById('syncPickBtn');
        const regrantBtn = document.getElementById('syncRegrantBtn');
        const disconnectBtn = document.getElementById('syncDisconnectBtn');

        if (!statusEl) return;

        if (connected) {
            statusEl.textContent = '🟢 Connected';
            statusEl.style.color = 'var(--success)';
            dirNameEl.textContent = this.dirHandle?.name || 'Selected Directory';
            pickBtn.style.display = 'none';
            regrantBtn.style.display = 'none';
            disconnectBtn.style.display = 'inline-flex';
        } else if (this.dirHandle && !connected) {
            statusEl.textContent = '🟡 Needs Permission';
            statusEl.style.color = 'var(--warning)';
            dirNameEl.textContent = message || this.dirHandle?.name || '';
            pickBtn.style.display = 'none';
            regrantBtn.style.display = 'inline-flex';
            disconnectBtn.style.display = 'inline-flex';
        } else {
            statusEl.textContent = '⚪ Not Connected';
            statusEl.style.color = 'var(--text-tertiary)';
            dirNameEl.textContent = 'No directory selected';
            pickBtn.style.display = 'inline-flex';
            regrantBtn.style.display = 'none';
            disconnectBtn.style.display = 'none';
        }
    },

    _flashStatus(msg) {
        const el = document.getElementById('syncFlash');
        if (!el) return;
        el.textContent = msg;
        el.style.opacity = '1';
        setTimeout(() => { el.style.opacity = '0'; }, 2500);
    }
};
