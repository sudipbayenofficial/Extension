// ==========================================
// SECOND BRAIN — Mind Map Module (mindmap.js)
// ==========================================

const MindMap = {
    canvas: null,
    ctx: null,
    nodes: [],
    connections: [],
    selectedNode: null,
    isDragging: false,
    dragOffsetX: 0,
    dragOffsetY: 0,
    nextId: 1,
    scale: 1,

    init() {
        this.canvas = document.getElementById('mindmapCanvas');
        this.ctx = this.canvas.getContext('2d');

        // Buttons
        document.getElementById('mmAddNode').addEventListener('click', () => this.addNode());
        document.getElementById('mmZoomIn').addEventListener('click', () => this.zoom(0.1));
        document.getElementById('mmZoomOut').addEventListener('click', () => this.zoom(-0.1));
        document.getElementById('mmReset').addEventListener('click', () => this.reset());

        // Canvas events
        this.canvas.addEventListener('mousedown', (e) => this.onMouseDown(e));
        this.canvas.addEventListener('mousemove', (e) => this.onMouseMove(e));
        this.canvas.addEventListener('mouseup', () => this.onMouseUp());
        this.canvas.addEventListener('dblclick', (e) => this.onDblClick(e));

        // Resize
        window.addEventListener('resize', () => this.resizeCanvas());
    },

    resizeCanvas() {
        const container = this.canvas.parentElement;
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;
        this.draw();
    },

    addNode(text = 'New Idea', x = null, y = null) {
        const node = {
            id: this.nextId++,
            text: text,
            x: x || this.canvas.width / 2 + (Math.random() - 0.5) * 200,
            y: y || this.canvas.height / 2 + (Math.random() - 0.5) * 200,
            width: 140,
            height: 50,
            color: this._randomColor(),
            parentId: this.selectedNode ? this.selectedNode.id : null
        };

        this.nodes.push(node);

        // Connect to selected/parent
        if (this.selectedNode) {
            this.connections.push({
                from: this.selectedNode.id,
                to: node.id
            });
        }

        this.selectedNode = node;
        this.draw();
        this._save();
    },

    reset() {
        this.nodes = [];
        this.connections = [];
        this.selectedNode = null;
        this.nextId = 1;
        this.scale = 1;

        // Create root node
        this.addNode('Central Idea', this.canvas.width / 2, this.canvas.height / 2);
        this.selectedNode = null;
        this.draw();
        this._save();
    },

    zoom(delta) {
        this.scale = Math.max(0.3, Math.min(2, this.scale + delta));
        this.draw();
    },

    // --- Drawing ---

    draw() {
        if (!this.ctx) return;
        const ctx = this.ctx;
        const w = this.canvas.width;
        const h = this.canvas.height;

        ctx.clearRect(0, 0, w, h);
        ctx.save();
        ctx.scale(this.scale, this.scale);

        // Draw connections
        this.connections.forEach(conn => {
            const from = this.nodes.find(n => n.id === conn.from);
            const to = this.nodes.find(n => n.id === conn.to);
            if (!from || !to) return;

            ctx.beginPath();
            ctx.moveTo(from.x + from.width / 2, from.y + from.height / 2);

            // Bezier curve
            const cpX = (from.x + to.x) / 2 + from.width / 2;
            const cpY = (from.y + to.y) / 2;
            ctx.quadraticCurveTo(cpX, cpY,
                to.x + to.width / 2, to.y + to.height / 2);

            ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
            ctx.lineWidth = 2;
            ctx.stroke();
        });

        // Draw nodes
        this.nodes.forEach(node => {
            const isSelected = this.selectedNode && this.selectedNode.id === node.id;

            // Shadow
            ctx.shadowColor = isSelected ? 'rgba(56, 189, 248, 0.4)' : 'rgba(0,0,0,0.3)';
            ctx.shadowBlur = isSelected ? 20 : 10;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 4;

            // Node body
            ctx.fillStyle = node.color;
            this._roundRect(ctx, node.x, node.y, node.width, node.height, 10);
            ctx.fill();

            // Border
            ctx.shadowColor = 'transparent';
            ctx.strokeStyle = isSelected ? '#38bdf8' : 'rgba(255,255,255,0.1)';
            ctx.lineWidth = isSelected ? 2 : 1;
            this._roundRect(ctx, node.x, node.y, node.width, node.height, 10);
            ctx.stroke();

            // Text
            ctx.fillStyle = '#e2e8f0';
            ctx.font = '13px Inter, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(node.text, node.x + node.width / 2, node.y + node.height / 2, node.width - 16);
        });

        ctx.restore();
    },

    _roundRect(ctx, x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + r);
        ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.closePath();
    },

    _randomColor() {
        const colors = [
            'rgba(30, 41, 59, 0.9)',
            'rgba(15, 23, 42, 0.9)',
            'rgba(29, 38, 58, 0.9)',
            'rgba(24, 32, 52, 0.9)',
        ];
        return colors[Math.floor(Math.random() * colors.length)];
    },

    // --- Interaction ---

    _getNodeAt(x, y) {
        const sx = x / this.scale;
        const sy = y / this.scale;
        // Reverse order so top nodes are selected first
        for (let i = this.nodes.length - 1; i >= 0; i--) {
            const n = this.nodes[i];
            if (sx >= n.x && sx <= n.x + n.width && sy >= n.y && sy <= n.y + n.height) {
                return n;
            }
        }
        return null;
    },

    onMouseDown(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const node = this._getNodeAt(x, y);
        if (node) {
            this.selectedNode = node;
            this.isDragging = true;
            this.dragOffsetX = x / this.scale - node.x;
            this.dragOffsetY = y / this.scale - node.y;
            this.canvas.style.cursor = 'grabbing';
        } else {
            this.selectedNode = null;
        }
        this.draw();
    },

    onMouseMove(e) {
        if (!this.isDragging || !this.selectedNode) return;
        const rect = this.canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        this.selectedNode.x = x / this.scale - this.dragOffsetX;
        this.selectedNode.y = y / this.scale - this.dragOffsetY;
        this.draw();
    },

    onMouseUp() {
        if (this.isDragging) {
            this.isDragging = false;
            this.canvas.style.cursor = 'grab';
            this._save();
        }
    },

    onDblClick(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const node = this._getNodeAt(x, y);

        if (node) {
            const newText = prompt('Edit node text:', node.text);
            if (newText !== null) {
                node.text = newText;
                this.draw();
                this._save();
            }
        } else {
            // Add new node at click position
            this.addNode('New Idea', x / this.scale - 70, y / this.scale - 25);
        }
    },

    // --- Persistence ---

    async _save() {
        await DB.put('mindmaps', {
            id: 'main',
            nodes: this.nodes,
            connections: this.connections,
            nextId: this.nextId
        });
        if (typeof Sync !== 'undefined') Sync.saveStore('mindmaps');
    },

    async load() {
        this.resizeCanvas();
        const data = await DB.get('mindmaps', 'main');
        if (data) {
            this.nodes = data.nodes || [];
            this.connections = data.connections || [];
            this.nextId = data.nextId || 1;
        } else {
            // First time: create a central node
            this.addNode('My Brain', this.canvas.width / 2 - 70, this.canvas.height / 2 - 25);
            this.selectedNode = null;
        }
        this.draw();
    }
};
